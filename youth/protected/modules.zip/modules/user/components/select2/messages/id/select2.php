<?php
return array(
	'No matches found' => 'Tidak diketemukan hasil',
	'Please enter {chars} more characters' => 'Mohon memasukkan karakter lebih dari {chars}',
	'Please enter {chars} less characters' => 'Mohon memasukkan karakter kurang dari {chars}',
	'You can only select {count} items' => 'Anda hanya dapat memilih {count} item',
	'Loading more results...' => 'Memuat lebih banyak hasil...',
	'Searching...' => 'Mencari...',
);
