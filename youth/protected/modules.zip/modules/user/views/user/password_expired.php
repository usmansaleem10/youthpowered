<div class="notice">
<?php 
echo Yum::t('Your password has expired. Please enter your new Password below:');

?>
</div>
