<?php
return array(
	'Edit text' => 'Texte bearbeiten',
);
?>
