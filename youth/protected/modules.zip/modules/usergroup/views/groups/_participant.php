<?php $this->renderPartial('user.views.user._view', array(
			'data' => $data)); ?>

