<h3> <?php echo Yum::t('The comment has been saved'); ?> </h3>

<?php echo CHtml::Button(Yum::t('Back'), array('onclick' => 'window.location.reload()')); ?>
