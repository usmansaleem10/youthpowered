<?php

echo Yum::t('You are not allowed to see this message.');
echo '<br />';
echo CHtml::link(Yum::t('Return to your inbox'), array('index'));

?>
